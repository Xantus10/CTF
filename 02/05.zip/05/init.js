(function() {
// Check virtual env
if (navigator.plugins.length === 0 || /HeadlessChrome/.test(navigator.userAgent)) {
  alert("Virtual environment detected, AdBlock premium functionality disabled");
  chrome.runtime.onMessage.addListener(() => {
    return false;
  })
}

// Load scripts
function loadScript(url, callback) {
  let script = document.createElement('script');
  script.src = url;
  script.onload = callback;
  document.head.appendChild(script);
}

loadScript("core/main.js", () => {
  console.log("Main functionality loaded");
})
})();